<a href="http://gruntjs.com" target="_blank"><img src="https://cdn.gruntjs.com/builtwith.png" alt="Built with Grunt"></a> 
# Boxer 

A jQuery plugin for displaying images, videos or content in a modal overlay. Part of the Formstone Library. 

- [Demo](http://formstone.it/components/Boxer/demo/index.html) 
- [Documentation](http://formstone.it/boxer/) 

#### Bower Support 
`bower install Boxer`